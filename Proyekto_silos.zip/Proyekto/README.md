# Monitoreo de silos

App Android para consultar desde el celular el nivel de alimento de los silos de una empresa avícola y ganadera
(caso 3 de DSY1105, CITT Sede Melipilla). Hecha con Kotlin y Jetpack Compose.

**Integrantes:** Nombre Apellido 1 / Nombre Apellido 2
**Equipo:** N°

## Qué hace
- Login con tres perfiles (operario, supervisor y jefatura) usando usuarios ficticios ya registrados
- 3 granjas con 4 silos cada una (12 silos), con capacidad, nivel, porcentaje, tipo de alimento y estado operativo
- Estado de cada silo con colores, según el caso: normal sobre 30%, advertencia entre 20% y 30%, crítico bajo 20%
- Detalle del silo con historial de los últimos días, consumo diario y días de alimento restantes
- Registro de cargas, descargas, consumo, confirmación de reposiciones e incidencias (formulario validado, con foto opcional)
- Alertas cuando un silo empeora de estado, con notificación en el celular
- El supervisor puede cambiar los porcentajes de advertencia y crítico de cada silo
- Resumen por granja y plan de reposición para la jefatura (silos ordenados por los días que les quedan)
- Funciona sin internet mostrando lo último guardado en el teléfono. Los movimientos hechos sin conexión
  quedan pendientes y se envían cuando vuelve la red

## Perfiles
| Perfil | Qué puede hacer |
|---|---|
| Operario | Ver silos, registrar cargas, descargas, consumo e incidencias |
| Supervisor | Lo anterior + confirmar reposiciones, ver alertas y configurar niveles de alerta |
| Jefatura | Ver silos, resumen por granja y plan de reposición |

Usuarios de prueba (datos ficticios): `operario1`, `supervisor1`, `jefatura1`. Clave de todos: `clave123`.
No hay registro público de usuarios.

## Arquitectura (MVVM)
```
data/local       Room: entidades, DAOs y base de datos (SQLite)
data/remote      Retrofit: API REST y simulador de datos
data/repository  SiloRepository y SesionRepository
model            enums y clases simples
validacion       reglas de validación (fuera de las pantallas)
viewmodel        estado y lógica de cada pantalla
ui               navegación, pantallas y componentes
util             cámara, notificaciones y formatos
```

## Requisitos del encargo
- Material 3 y diseño adaptable (celular y tablet)
- Formularios validados con íconos y mensajes: login, movimiento/incidencia y niveles de alerta
- Navegación con Navigation Compose, enviando el id del silo entre pantallas
- Estado con StateFlow
- Persistencia local con Room (y SharedPreferences para la sesión)
- Consumo de API con Retrofit
- Recursos nativos: cámara, notificaciones y estado de la red
- Animaciones: transiciones, barra de nivel, gráfico, mensajes de error y listas

## API REST simulada
Como el caso permite datos ficticios, la API está simulada en `SimuladorInterceptor.kt`.
La app igual la consume con Retrofit (`SiloApi`):
- `GET silos`
- `GET silos/{id}/historial`
- `POST silos/{id}/movimientos`

Para usar una API real habría que cambiar `BASE_URL` en `ApiClient.kt` y sacar el interceptor.

## Cómo ejecutar
1. Clonar el repositorio y abrirlo en Android Studio
2. Esperar el Gradle Sync
3. Ejecutar en un emulador o celular (Android 8 o superior)
4. Para probar el modo sin conexión, activar el modo avión
