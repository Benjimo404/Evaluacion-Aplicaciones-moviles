package com.example.proyekto

import com.example.proyekto.data.local.SiloEntity
import com.example.proyekto.data.local.estado
import com.example.proyekto.data.local.porcentaje
import com.example.proyekto.model.EstadoSilo
import org.junit.Assert.assertEquals
import org.junit.Test

// niveles del caso: normal sobre 30%, advertencia entre 20% y 30%, critico bajo 20%
class EstadoSiloTest {

    private fun silo(nivel: Double) =
        SiloEntity("S-01", "Granja", "Silo 1", 10000.0, nivel, 1000.0)

    @Test
    fun calculaElPorcentaje() = assertEquals(35, silo(3500.0).porcentaje)

    @Test
    fun sobre30EsNormal() = assertEquals(EstadoSilo.NORMAL, silo(3500.0).estado)

    @Test
    fun entre20y30EsAdvertencia() = assertEquals(EstadoSilo.ADVERTENCIA, silo(2500.0).estado)

    @Test
    fun el30ExactoEsAdvertencia() = assertEquals(EstadoSilo.ADVERTENCIA, silo(3000.0).estado)

    @Test
    fun el20ExactoEsAdvertencia() = assertEquals(EstadoSilo.ADVERTENCIA, silo(2000.0).estado)

    @Test
    fun bajo20EsCritico() = assertEquals(EstadoSilo.CRITICO, silo(1500.0).estado)

    @Test
    fun respetaUmbralesPersonalizados() {
        val s = silo(5000.0).copy(umbralAdvertencia = 60, umbralCritico = 55)
        assertEquals(EstadoSilo.CRITICO, s.estado)
    }
}
