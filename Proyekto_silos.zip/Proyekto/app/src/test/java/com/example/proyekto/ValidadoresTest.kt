package com.example.proyekto

import com.example.proyekto.data.local.SiloEntity
import com.example.proyekto.model.TipoMovimiento
import com.example.proyekto.validacion.ValidadorLogin
import com.example.proyekto.validacion.ValidadorMovimiento
import com.example.proyekto.validacion.ValidadorUmbral
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ValidadoresTest {

    private val silo = SiloEntity("S-01", "Granja", "Silo 1", 10000.0, 4000.0, 1000.0)

    @Test
    fun usuarioVacio_daError() = assertNotNull(ValidadorLogin.usuario(""))

    @Test
    fun usuarioConSimbolos_daError() = assertNotNull(ValidadorLogin.usuario("pe*dro"))

    @Test
    fun usuarioValido_noDaError() = assertNull(ValidadorLogin.usuario("operario1"))

    @Test
    fun claveCorta_daError() = assertNotNull(ValidadorLogin.clave("123"))

    @Test
    fun cargaQueNoCabe_daError() =
        assertNotNull(ValidadorMovimiento.cantidad("7000", TipoMovimiento.CARGA, silo))

    @Test
    fun cargaQueCabe_noDaError() =
        assertNull(ValidadorMovimiento.cantidad("5000", TipoMovimiento.CARGA, silo))

    @Test
    fun descargaMayorAlNivel_daError() =
        assertNotNull(ValidadorMovimiento.cantidad("4500", TipoMovimiento.DESCARGA, silo))

    @Test
    fun cantidadConComa_seAcepta() =
        assertNull(ValidadorMovimiento.cantidad("1500,5", TipoMovimiento.CONSUMO, silo))

    @Test
    fun cantidadNegativa_daError() =
        assertNotNull(ValidadorMovimiento.cantidad("-5", TipoMovimiento.CARGA, silo))

    @Test
    fun reposicionQueNoCabe_daError() =
        assertNotNull(ValidadorMovimiento.cantidad("9000", TipoMovimiento.REPOSICION, silo))

    @Test
    fun incidencia_noPideCantidad() =
        assertNull(ValidadorMovimiento.cantidad("", TipoMovimiento.INCIDENCIA, silo))

    @Test
    fun incidenciaSinDescripcion_daError() =
        assertNotNull(ValidadorMovimiento.observacion("", TipoMovimiento.INCIDENCIA))

    @Test
    fun observacionEnCargaEsOpcional() =
        assertNull(ValidadorMovimiento.observacion("", TipoMovimiento.CARGA))

    @Test
    fun criticoMayorQueAdvertencia_daError() =
        assertNotNull(ValidadorUmbral.critico("50", "40"))

    @Test
    fun umbralesCorrectos_noDanError() {
        assertNull(ValidadorUmbral.advertencia("40"))
        assertNull(ValidadorUmbral.critico("20", "40"))
    }
}
