package com.example.proyekto.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SiloDao {
    @Query("SELECT * FROM silos ORDER BY granja, nombre")
    fun observarTodos(): Flow<List<SiloEntity>>

    @Query("SELECT * FROM silos WHERE id = :id")
    fun observarPorId(id: String): Flow<SiloEntity?>

    @Query("SELECT * FROM silos WHERE id = :id")
    suspend fun obtenerPorId(id: String): SiloEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun guardar(silo: SiloEntity)

    @Query("UPDATE silos SET umbralAdvertencia = :adv, umbralCritico = :crit WHERE id = :id")
    suspend fun actualizarUmbrales(id: String, adv: Int, crit: Int)
}

@Dao
interface MovimientoDao {
    @Query("SELECT * FROM movimientos WHERE siloId = :siloId ORDER BY fecha DESC LIMIT 20")
    fun observarPorSilo(siloId: String): Flow<List<MovimientoEntity>>

    @Query("SELECT * FROM movimientos WHERE sincronizado = 0")
    suspend fun pendientes(): List<MovimientoEntity>

    @Insert
    suspend fun insertar(movimiento: MovimientoEntity): Long

    @Query("UPDATE movimientos SET sincronizado = 1 WHERE id = :id")
    suspend fun marcarSincronizado(id: Long)
}

@Dao
interface HistorialDao {
    @Query("SELECT * FROM historial WHERE siloId = :siloId ORDER BY fecha ASC")
    fun observarPorSilo(siloId: String): Flow<List<HistorialEntity>>

    @Query("DELETE FROM historial WHERE siloId = :siloId")
    suspend fun borrarPorSilo(siloId: String)

    @Insert
    suspend fun insertarTodos(lista: List<HistorialEntity>)
}

@Dao
interface AlertaDao {
    @Query("SELECT * FROM alertas ORDER BY fecha DESC")
    fun observarTodas(): Flow<List<AlertaEntity>>

    @Query("SELECT COUNT(*) FROM alertas WHERE leida = 0")
    fun contarNoLeidas(): Flow<Int>

    @Insert
    suspend fun insertar(alerta: AlertaEntity): Long

    @Query("UPDATE alertas SET leida = 1 WHERE id = :id")
    suspend fun marcarLeida(id: Long)

    @Query("UPDATE alertas SET leida = 1")
    suspend fun marcarTodasLeidas()
}
