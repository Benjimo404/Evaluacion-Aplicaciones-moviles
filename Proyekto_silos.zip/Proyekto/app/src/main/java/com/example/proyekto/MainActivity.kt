package com.example.proyekto

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Surface
import com.example.proyekto.ui.AppNavegacion
import com.example.proyekto.ui.theme.ProyektoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ProyektoTheme {
                Surface { AppNavegacion() }
            }
        }
    }
}
