package com.example.proyekto.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.proyekto.ProyektoApp
import com.example.proyekto.data.local.AlertaEntity
import com.example.proyekto.data.local.HistorialEntity
import com.example.proyekto.data.local.MovimientoEntity
import com.example.proyekto.data.local.SiloEntity
import com.example.proyekto.data.local.estado
import com.example.proyekto.data.local.diasRestantes
import com.example.proyekto.model.EstadoSilo
import com.example.proyekto.util.Notificaciones
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ResumenGranja(
    val granja: String,
    val cantidadSilos: Int,
    val capacidadKg: Double,
    val nivelKg: Double,
    val criticos: Int,
    val consumoDiarioKg: Double
) {
    val porcentaje: Int get() = if (capacidadKg <= 0) 0 else ((nivelKg / capacidadKg) * 100).toInt()
}

class SiloViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = (app as ProyektoApp).repositorio

    private val _filtroGranja = MutableStateFlow<String?>(null)
    val filtroGranja: StateFlow<String?> = _filtroGranja.asStateFlow()

    private val _actualizando = MutableStateFlow(false)
    val actualizando: StateFlow<Boolean> = _actualizando.asStateFlow()

    private val _sinConexion = MutableStateFlow(false)
    val sinConexion: StateFlow<Boolean> = _sinConexion.asStateFlow()

    private val _mensaje = MutableStateFlow<String?>(null)
    val mensaje: StateFlow<String?> = _mensaje.asStateFlow()

    private var monitoreo: Job? = null

    // lista de silos (filtrada por granja si hay un filtro puesto)
    val silos: StateFlow<List<SiloEntity>> = combine(repo.silos, _filtroGranja) { lista, filtro ->
        if (filtro == null) lista else lista.filter { it.granja == filtro }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val granjas: StateFlow<List<String>> = repo.silos
        .map { lista -> lista.map { it.granja }.distinct() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val alertas: StateFlow<List<AlertaEntity>> = repo.alertas
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val alertasSinLeer: StateFlow<Int> = repo.alertasSinLeer
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // para la jefatura
    val resumen: StateFlow<List<ResumenGranja>> = repo.silos.map { lista ->
        lista.groupBy { it.granja }.map { (granja, silos) ->
            ResumenGranja(
                granja = granja,
                cantidadSilos = silos.size,
                capacidadKg = silos.sumOf { it.capacidadKg },
                nivelKg = silos.sumOf { it.nivelKg },
                criticos = silos.count { it.estado == EstadoSilo.CRITICO },
                consumoDiarioKg = silos.sumOf { it.consumoDiarioKg }
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // silos ordenados por los dias que les quedan (los mas urgentes primero)
    val reposiciones: StateFlow<List<SiloEntity>> = repo.silos
        .map { lista -> lista.sortedBy { it.diasRestantes } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setFiltro(granja: String?) {
        _filtroGranja.value = granja
    }

    // consulta la API cada 30 segundos mientras haya sesion
    fun iniciarMonitoreo() {
        if (monitoreo?.isActive == true) return
        monitoreo = viewModelScope.launch {
            while (true) {
                actualizar()
                delay(30_000)
            }
        }
    }

    fun detenerMonitoreo() {
        monitoreo?.cancel()
        monitoreo = null
    }

    fun refrescar() {
        viewModelScope.launch { actualizar() }
    }

    private suspend fun actualizar() {
        if (_actualizando.value) return
        _actualizando.value = true
        val resultado = repo.refrescar()
        _sinConexion.value = !resultado.exito
        if (!resultado.exito) _mensaje.value = resultado.error
        resultado.alertasNuevas.forEach { Notificaciones.mostrarAlerta(getApplication<Application>(), it) }
        _actualizando.value = false
    }

    fun consumirMensaje() {
        _mensaje.value = null
    }

    fun observarSilo(id: String): Flow<SiloEntity?> = repo.silo(id)
    fun observarHistorial(id: String): Flow<List<HistorialEntity>> = repo.historial(id)
    fun observarMovimientos(id: String): Flow<List<MovimientoEntity>> = repo.movimientos(id)

    fun cargarHistorial(id: String) {
        viewModelScope.launch { repo.cargarHistorial(id) }
    }

    fun marcarLeida(id: Long) {
        viewModelScope.launch { repo.marcarAlertaLeida(id) }
    }

    fun marcarTodasLeidas() {
        viewModelScope.launch { repo.marcarTodasLeidas() }
    }
}
