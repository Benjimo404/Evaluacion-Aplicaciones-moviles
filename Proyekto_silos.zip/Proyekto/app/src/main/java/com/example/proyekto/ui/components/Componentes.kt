package com.example.proyekto.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.proyekto.model.EstadoSilo
import com.example.proyekto.model.Rol
import com.example.proyekto.model.Sesion
import com.example.proyekto.ui.Rutas
import com.example.proyekto.ui.theme.EstadoAdvertencia
import com.example.proyekto.ui.theme.EstadoCritico
import com.example.proyekto.ui.theme.EstadoNormal

fun colorEstado(estado: EstadoSilo): Color = when (estado) {
    EstadoSilo.NORMAL -> EstadoNormal
    EstadoSilo.ADVERTENCIA -> EstadoAdvertencia
    EstadoSilo.CRITICO -> EstadoCritico
}

private fun iconoEstado(estado: EstadoSilo): ImageVector = when (estado) {
    EstadoSilo.NORMAL -> Icons.Default.CheckCircle
    EstadoSilo.ADVERTENCIA -> Icons.Default.Warning
    EstadoSilo.CRITICO -> Icons.Default.Error
}

@Composable
fun EstadoChip(estado: EstadoSilo) {
    val color = colorEstado(estado)
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.15f)) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(iconoEstado(estado), contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(estado.etiqueta, color = color, style = MaterialTheme.typography.labelMedium)
        }
    }
}

// barra de nivel que se llena con animacion
@Composable
fun BarraNivel(porcentaje: Int, estado: EstadoSilo, modifier: Modifier = Modifier) {
    val progreso by animateFloatAsState(
        targetValue = porcentaje / 100f,
        animationSpec = tween(700),
        label = "nivel"
    )
    LinearProgressIndicator(
        progress = { progreso },
        modifier = modifier.fillMaxWidth().height(10.dp),
        color = colorEstado(estado),
        trackColor = MaterialTheme.colorScheme.surfaceVariant,
        strokeCap = androidx.compose.ui.graphics.StrokeCap.Round
    )
}

// grafico de barras simple. valores van de 0 a 1
@Composable
fun GraficoBarras(
    valores: List<Float>,
    etiquetas: List<String>,
    color: Color,
    modifier: Modifier = Modifier
) {
    var iniciado by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { iniciado = true }

    Row(
        modifier = modifier.fillMaxWidth().height(170.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        valores.forEachIndexed { i, valor ->
            val alto by animateFloatAsState(
                targetValue = if (iniciado) valor.coerceIn(0f, 1f) else 0f,
                animationSpec = tween(600, delayMillis = i * 60),
                label = "barra"
            )
            Column(
                modifier = Modifier.weight(1f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("${(valor * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(alto.coerceAtLeast(0.02f))
                            .background(color, RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                    )
                }
                Text(etiquetas.getOrElse(i) { "" }, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
fun CampoTexto(
    label: String,
    value: String,
    error: String?,
    icono: ImageVector,
    onChange: (String) -> Unit,
    tipo: KeyboardType = KeyboardType.Text,
    visual: VisualTransformation = VisualTransformation.None,
    extraFinal: (@Composable () -> Unit)? = null,
    sufijo: String? = null,
    singleLine: Boolean = true
) {
    Column {
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            label = { Text(label) },
            leadingIcon = { Icon(icono, contentDescription = null) },
            trailingIcon = {
                if (error != null) {
                    Icon(Icons.Default.Warning, contentDescription = "Error", tint = MaterialTheme.colorScheme.error)
                } else {
                    extraFinal?.invoke()
                }
            },
            suffix = sufijo?.let { { Text(it) } },
            isError = error != null,
            singleLine = singleLine,
            visualTransformation = visual,
            keyboardOptions = KeyboardOptions(keyboardType = tipo),
            modifier = Modifier.fillMaxWidth()
        )
        AnimatedVisibility(visible = error != null) {
            Text(
                error ?: "",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(start = 16.dp, top = 4.dp)
            )
        }
    }
}

// ---------- estructura comun de las pantallas principales ----------

private data class Destino(val ruta: String, val etiqueta: String, val icono: ImageVector)

private fun destinosPara(rol: Rol): List<Destino> {
    val silos = Destino(Rutas.SILOS, "Silos", Icons.Default.Home)
    val alertas = Destino(Rutas.ALERTAS, "Alertas", Icons.Default.Notifications)
    val resumen = Destino(Rutas.RESUMEN, "Resumen", Icons.Default.Assessment)
    return when (rol) {
        Rol.OPERARIO -> listOf(silos)
        Rol.SUPERVISOR -> listOf(silos, alertas)
        Rol.JEFATURA -> listOf(silos, resumen)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EstructuraPrincipal(
    titulo: String,
    rutaActual: String,
    sesion: Sesion,
    alertasSinLeer: Int,
    onIr: (String) -> Unit,
    onSalir: () -> Unit,
    snackbarHostState: SnackbarHostState,
    acciones: @Composable RowScope.() -> Unit = {},
    contenido: @Composable (PaddingValues) -> Unit
) {
    val destinos = destinosPara(sesion.rol)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(titulo)
                        Text(
                            "${sesion.nombre} · ${sesion.rol.titulo}",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                actions = {
                    acciones()
                    IconButton(onClick = onSalir) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Cerrar sesión")
                    }
                }
            )
        },
        bottomBar = {
            // el operario solo tiene una pestaña, no hace falta la barra
            if (destinos.size > 1) {
                NavigationBar {
                    destinos.forEach { d ->
                        NavigationBarItem(
                            selected = d.ruta == rutaActual,
                            onClick = { onIr(d.ruta) },
                            icon = {
                                if (d.ruta == Rutas.ALERTAS && alertasSinLeer > 0) {
                                    BadgedBox(badge = { Badge { Text("$alertasSinLeer") } }) {
                                        Icon(d.icono, contentDescription = null)
                                    }
                                } else {
                                    Icon(d.icono, contentDescription = null)
                                }
                            },
                            label = { Text(d.etiqueta) }
                        )
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        content = contenido
    )
}
