package com.example.proyekto.validacion

import com.example.proyekto.data.local.SiloEntity
import com.example.proyekto.model.TipoMovimiento
import kotlin.math.roundToInt

// Las validaciones estan aca y no en las pantallas.
// Todas devuelven null si esta bien o el mensaje de error si no.

object ValidadorLogin {

    fun usuario(v: String): String? = when {
        v.isBlank() -> "Ingresa tu usuario"
        v.length < 4 -> "El usuario debe tener al menos 4 caracteres"
        !v.all { it.isLetterOrDigit() } -> "Solo se permiten letras y números"
        else -> null
    }

    fun clave(v: String): String? = when {
        v.isBlank() -> "Ingresa tu clave"
        v.length < 6 -> "La clave debe tener al menos 6 caracteres"
        else -> null
    }
}

object ValidadorMovimiento {

    fun cantidad(texto: String, tipo: TipoMovimiento, silo: SiloEntity?): String? {
        // la incidencia no lleva cantidad
        if (!tipo.afectaNivel) return null
        if (texto.isBlank()) return "Ingresa la cantidad en kg"
        val n = texto.replace(',', '.').toDoubleOrNull() ?: return "Ingresa un número válido"
        if (n <= 0) return "La cantidad debe ser mayor a 0"
        if (silo == null) return null

        return if (tipo.aumentaNivel) {
            val libre = silo.capacidadKg - silo.nivelKg
            if (n > libre) "Supera el espacio libre del silo (${libre.roundToInt()} kg)" else null
        } else {
            if (n > silo.nivelKg) "Supera el alimento disponible (${silo.nivelKg.roundToInt()} kg)" else null
        }
    }

    // en las incidencias la descripcion es obligatoria, en los demas es opcional
    fun observacion(v: String, tipo: TipoMovimiento): String? = when {
        tipo == TipoMovimiento.INCIDENCIA && v.isBlank() -> "Describe la incidencia"
        tipo == TipoMovimiento.INCIDENCIA && v.trim().length < 5 -> "Mínimo 5 caracteres"
        v.length > 120 -> "Máximo 120 caracteres"
        else -> null
    }
}

object ValidadorUmbral {

    fun advertencia(v: String): String? {
        if (v.isBlank()) return "Ingresa el porcentaje"
        val n = v.toIntOrNull() ?: return "Ingresa un número entero"
        return if (n !in 2..99) "Debe estar entre 2 y 99" else null
    }

    fun critico(v: String, advertencia: String): String? {
        if (v.isBlank()) return "Ingresa el porcentaje"
        val n = v.toIntOrNull() ?: return "Ingresa un número entero"
        if (n !in 1..98) return "Debe estar entre 1 y 98"
        val adv = advertencia.toIntOrNull()
        return if (adv != null && n >= adv) "Debe ser menor al umbral de advertencia" else null
    }
}
