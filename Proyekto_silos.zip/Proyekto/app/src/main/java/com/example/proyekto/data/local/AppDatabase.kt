package com.example.proyekto.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [SiloEntity::class, MovimientoEntity::class, HistorialEntity::class, AlertaEntity::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun siloDao(): SiloDao
    abstract fun movimientoDao(): MovimientoDao
    abstract fun historialDao(): HistorialDao
    abstract fun alertaDao(): AlertaDao

    companion object {
        @Volatile
        private var instancia: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instancia ?: synchronized(this) {
                instancia ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "silos.db"
                )
                    .fallbackToDestructiveMigration() // es un MVP, si cambia la tabla se vuelve a crear
                    .build().also { instancia = it }
            }
    }
}
