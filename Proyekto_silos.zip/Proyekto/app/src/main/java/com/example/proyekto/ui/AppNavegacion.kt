package com.example.proyekto.ui

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.proyekto.ui.screen.AlertasScreen
import com.example.proyekto.ui.screen.DetalleSiloScreen
import com.example.proyekto.ui.screen.LoginScreen
import com.example.proyekto.ui.screen.MovimientoScreen
import com.example.proyekto.ui.screen.ResumenScreen
import com.example.proyekto.ui.screen.SilosScreen
import com.example.proyekto.ui.screen.UmbralScreen
import com.example.proyekto.viewmodel.MovimientoViewModel
import com.example.proyekto.viewmodel.SesionViewModel
import com.example.proyekto.viewmodel.SiloViewModel
import com.example.proyekto.viewmodel.UmbralViewModel

@Composable
fun AppNavegacion() {
    val nav = rememberNavController()

    // estos dos viewmodels se comparten entre varias pantallas
    val sesionVm: SesionViewModel = viewModel()
    val siloVm: SiloViewModel = viewModel()
    val sesion by sesionVm.sesion.collectAsStateWithLifecycle()

    // si ya habia iniciado sesion antes, entra directo
    val inicio = remember { if (sesionVm.sesion.value != null) Rutas.SILOS else Rutas.LOGIN }

    fun irA(ruta: String) {
        nav.navigate(ruta) {
            popUpTo(Rutas.SILOS)
            launchSingleTop = true
        }
    }

    fun salir() {
        siloVm.detenerMonitoreo()
        sesionVm.cerrar()
        nav.navigate(Rutas.LOGIN) {
            popUpTo(nav.graph.id) { inclusive = true }
        }
    }

    NavHost(
        navController = nav,
        startDestination = inicio,
        enterTransition = { slideInHorizontally { it / 2 } + fadeIn() },
        exitTransition = { fadeOut() },
        popEnterTransition = { fadeIn() },
        popExitTransition = { slideOutHorizontally { it / 2 } + fadeOut() }
    ) {
        composable(Rutas.LOGIN) {
            LoginScreen(onIngresar = { s ->
                sesionVm.iniciar(s)
                nav.navigate(Rutas.SILOS) {
                    popUpTo(Rutas.LOGIN) { inclusive = true }
                }
            })
        }

        composable(Rutas.SILOS) {
            val s = sesion ?: return@composable
            SilosScreen(
                sesion = s,
                vm = siloVm,
                onIr = ::irA,
                onSalir = ::salir,
                onAbrirSilo = { id -> nav.navigate(Rutas.detalle(id)) }
            )
        }

        composable(Rutas.ALERTAS) {
            val s = sesion ?: return@composable
            AlertasScreen(
                sesion = s,
                vm = siloVm,
                onIr = ::irA,
                onSalir = ::salir,
                onAbrirSilo = { id -> nav.navigate(Rutas.detalle(id)) }
            )
        }

        composable(Rutas.RESUMEN) {
            val s = sesion ?: return@composable
            ResumenScreen(
                sesion = s,
                vm = siloVm,
                onIr = ::irA,
                onSalir = ::salir,
                onAbrirSilo = { id -> nav.navigate(Rutas.detalle(id)) }
            )
        }

        // las pantallas de abajo reciben el id del silo por la ruta
        composable(Rutas.DETALLE, arguments = listOf(navArgument("id") { type = NavType.StringType })) { entrada ->
            val s = sesion ?: return@composable
            val id = entrada.arguments?.getString("id") ?: return@composable
            DetalleSiloScreen(
                siloId = id,
                sesion = s,
                vm = siloVm,
                onVolver = { nav.popBackStack() },
                onMovimiento = { nav.navigate(Rutas.movimiento(id)) },
                onUmbral = { nav.navigate(Rutas.umbral(id)) }
            )
        }

        composable(Rutas.MOVIMIENTO, arguments = listOf(navArgument("id") { type = NavType.StringType })) { entrada ->
            val s = sesion ?: return@composable
            val id = entrada.arguments?.getString("id") ?: return@composable
            val vm: MovimientoViewModel = viewModel()
            MovimientoScreen(siloId = id, rol = s.rol, vm = vm, onVolver = { nav.popBackStack() })
        }

        composable(Rutas.UMBRAL, arguments = listOf(navArgument("id") { type = NavType.StringType })) { entrada ->
            val id = entrada.arguments?.getString("id") ?: return@composable
            val vm: UmbralViewModel = viewModel()
            UmbralScreen(siloId = id, vm = vm, onVolver = { nav.popBackStack() })
        }
    }
}
