package com.example.proyekto.data.remote

import com.example.proyekto.model.TipoMovimiento
import com.google.gson.Gson
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import okio.Buffer
import java.util.Random

// Hace de "servidor" del sistema de monitoreo. Como el caso pide datos ficticios,
// las respuestas se generan aca mismo pero la app las consume con Retrofit igual
// que si fuera una API real.
class SimuladorInterceptor : Interceptor {

    private val gson = Gson()

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val ruta = request.url.encodedPath
        Thread.sleep(300) // para que se note que "viaja" por la red

        val json = when {
            request.method == "GET" && ruta.endsWith("/historial") -> {
                val id = ruta.removeSuffix("/historial").substringAfterLast("/")
                gson.toJson(DatosSimulados.historial(id))
            }
            request.method == "GET" && ruta.endsWith("/silos") -> {
                gson.toJson(DatosSimulados.leerSilos())
            }
            request.method == "POST" && ruta.endsWith("/movimientos") -> {
                val id = ruta.removeSuffix("/movimientos").substringAfterLast("/")
                val buffer = Buffer()
                request.body?.writeTo(buffer)
                val mov = gson.fromJson(buffer.readUtf8(), MovimientoDto::class.java)
                gson.toJson(DatosSimulados.aplicarMovimiento(id, mov))
            }
            else -> return respuesta(request, 404, "{\"error\":\"no existe\"}")
        }
        return respuesta(request, 200, json)
    }

    private fun respuesta(request: okhttp3.Request, codigo: Int, cuerpo: String): Response =
        Response.Builder()
            .request(request)
            .protocol(Protocol.HTTP_1_1)
            .code(codigo)
            .message(if (codigo == 200) "OK" else "Error")
            .body(cuerpo.toResponseBody("application/json".toMediaType()))
            .build()
}

object DatosSimulados {

    private val random = Random()

    // 3 granjas con 4 silos cada una (12 en total), con distintos niveles para que haya de todo
    private val silos = mutableListOf(
        SiloDto("S-01", "Granja Los Aromos", "Silo 1", 30000.0, 21600.0, 1800.0, "Iniciador", "Operativo", 0L),
        SiloDto("S-02", "Granja Los Aromos", "Silo 2", 30000.0, 17400.0, 2100.0, "Crecimiento", "Operativo", 0L),
        SiloDto("S-03", "Granja Los Aromos", "Silo 3", 25000.0, 6750.0, 1500.0, "Engorda", "Operativo", 0L),
        SiloDto("S-04", "Granja Los Aromos", "Silo 4", 25000.0, 11250.0, 1400.0, "Finalizador", "Operativo", 0L),
        SiloDto("S-05", "Granja El Roble", "Silo A", 40000.0, 32400.0, 2600.0, "Engorda", "Operativo", 0L),
        SiloDto("S-06", "Granja El Roble", "Silo B", 40000.0, 14400.0, 2900.0, "Engorda", "Operativo", 0L),
        SiloDto("S-07", "Granja El Roble", "Silo C", 40000.0, 8800.0, 2700.0, "Finalizador", "Operativo", 0L),
        SiloDto("S-08", "Granja El Roble", "Silo D", 20000.0, 12800.0, 1200.0, "Iniciador", "En mantención", 0L),
        SiloDto("S-09", "Granja Santa Rosa", "Silo 1", 20000.0, 9800.0, 1300.0, "Crecimiento", "Operativo", 0L),
        SiloDto("S-10", "Granja Santa Rosa", "Silo 2", 20000.0, 3000.0, 1250.0, "Engorda", "Operativo", 0L),
        SiloDto("S-11", "Granja Santa Rosa", "Silo 3", 35000.0, 11550.0, 2200.0, "Finalizador", "Operativo", 0L),
        SiloDto("S-12", "Granja Santa Rosa", "Silo 4", 35000.0, 26950.0, 2000.0, "Crecimiento", "Operativo", 0L)
    )

    // cada vez que se consulta, los silos "consumieron" un poco
    @Synchronized
    fun leerSilos(): List<SiloDto> {
        val ahora = System.currentTimeMillis()
        for (i in silos.indices) {
            val s = silos[i]
            var nivel = s.nivelKg - s.capacidadKg * (0.004 + random.nextDouble() * 0.012)
            if (nivel < s.capacidadKg * 0.04) {
                nivel = s.capacidadKg * 0.95 // llego un camion y lo lleno
            }
            silos[i] = s.copy(nivelKg = nivel, actualizado = ahora)
        }
        return silos.toList()
    }

    // niveles de los ultimos 7 dias, calculados hacia atras desde el nivel actual
    @Synchronized
    fun historial(id: String): List<LecturaDto> {
        val s = silos.firstOrNull { it.id == id } ?: return emptyList()
        val unDia = 24L * 60 * 60 * 1000
        val ahora = System.currentTimeMillis()
        return (6 downTo 0).map { dia ->
            val r = Random(id.hashCode() * 31L + dia)
            val nivel = (s.nivelKg + s.consumoDiarioKg * dia * (0.85 + r.nextDouble() * 0.3))
                .coerceAtMost(s.capacidadKg)
            LecturaDto(nivel, ahora - dia * unDia)
        }
    }

    @Synchronized
    fun aplicarMovimiento(id: String, mov: MovimientoDto): RespuestaDto {
        val i = silos.indexOfFirst { it.id == id }
        if (i < 0) return RespuestaDto(false, 0.0)
        val s = silos[i]
        val tipo = TipoMovimiento.valueOf(mov.tipo)
        // una incidencia no cambia el nivel del silo
        val delta = when {
            !tipo.afectaNivel -> 0.0
            tipo.aumentaNivel -> mov.cantidadKg
            else -> -mov.cantidadKg
        }
        val nivel = (s.nivelKg + delta).coerceIn(0.0, s.capacidadKg)
        silos[i] = s.copy(nivelKg = nivel)
        return RespuestaDto(true, nivel)
    }
}
