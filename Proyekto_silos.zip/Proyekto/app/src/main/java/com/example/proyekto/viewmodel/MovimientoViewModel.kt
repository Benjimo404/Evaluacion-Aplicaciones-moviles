package com.example.proyekto.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.proyekto.ProyektoApp
import com.example.proyekto.data.local.SiloEntity
import com.example.proyekto.model.TipoMovimiento
import com.example.proyekto.util.Notificaciones
import com.example.proyekto.validacion.ValidadorMovimiento
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MovimientoForm(
    val tipo: TipoMovimiento = TipoMovimiento.CARGA,
    val cantidad: String = "",
    val observacion: String = "",
    val fotoUri: String? = null,
    val errorCantidad: String? = null,
    val errorObservacion: String? = null
)

class MovimientoViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = (app as ProyektoApp).repositorio

    private val _silo = MutableStateFlow<SiloEntity?>(null)
    val silo: StateFlow<SiloEntity?> = _silo.asStateFlow()

    private val _form = MutableStateFlow(MovimientoForm())
    val form: StateFlow<MovimientoForm> = _form.asStateFlow()

    fun cargar(siloId: String) {
        if (_silo.value?.id == siloId) return
        viewModelScope.launch {
            _silo.value = repo.obtenerSilo(siloId)
            _form.value = MovimientoForm()
        }
    }

    fun onTipo(tipo: TipoMovimiento) = _form.update {
        // al cambiar el tipo cambian las reglas, asi que se vuelve a validar lo que ya estaba escrito
        val errorCantidad = if (it.cantidad.isBlank()) null else ValidadorMovimiento.cantidad(it.cantidad, tipo, _silo.value)
        val errorObs = if (it.observacion.isBlank()) null else ValidadorMovimiento.observacion(it.observacion, tipo)
        it.copy(tipo = tipo, errorCantidad = errorCantidad, errorObservacion = errorObs)
    }

    fun onCantidad(v: String) = _form.update {
        it.copy(cantidad = v, errorCantidad = ValidadorMovimiento.cantidad(v, it.tipo, _silo.value))
    }

    fun onObservacion(v: String) = _form.update {
        it.copy(observacion = v, errorObservacion = ValidadorMovimiento.observacion(v, it.tipo))
    }

    fun onFoto(uri: String?) = _form.update { it.copy(fotoUri = uri) }

    fun limpiar() {
        _form.value = MovimientoForm()
        _silo.value = null
    }

    fun guardar(onExito: () -> Unit) {
        val f = _form.value
        val silo = _silo.value ?: return

        val errorCantidad = ValidadorMovimiento.cantidad(f.cantidad, f.tipo, silo)
        val errorObs = ValidadorMovimiento.observacion(f.observacion, f.tipo)
        if (errorCantidad != null || errorObs != null) {
            _form.update { it.copy(errorCantidad = errorCantidad, errorObservacion = errorObs) }
            return
        }

        viewModelScope.launch {
            val alerta = repo.registrarMovimiento(
                silo = silo,
                tipo = f.tipo,
                cantidadKg = if (f.tipo.afectaNivel) f.cantidad.replace(',', '.').toDouble() else 0.0,
                observacion = f.observacion.trim(),
                fotoUri = f.fotoUri
            )
            alerta?.let { Notificaciones.mostrarAlerta(getApplication<Application>(), it) }
            limpiar()
            onExito()
        }
    }
}
