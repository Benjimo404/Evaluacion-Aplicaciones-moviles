package com.example.proyekto.data.repository

import android.content.Context
import com.example.proyekto.model.Rol
import com.example.proyekto.model.Sesion

// usuarios de prueba (datos ficticios)
object UsuariosDemo {
    private val usuarios = listOf(
        Triple("operario1", "clave123", Sesion("operario1", "Pedro Soto", Rol.OPERARIO)),
        Triple("supervisor1", "clave123", Sesion("supervisor1", "Marcela Rojas", Rol.SUPERVISOR)),
        Triple("jefatura1", "clave123", Sesion("jefatura1", "Ivan Bilbao", Rol.JEFATURA))
    )

    fun autenticar(usuario: String, clave: String): Sesion? =
        usuarios.firstOrNull { it.first == usuario.trim().lowercase() && it.second == clave }?.third
}

// guarda quien inicio sesion para no pedir login cada vez que se abre la app
class SesionRepository(context: Context) {

    private val prefs = context.getSharedPreferences("sesion", Context.MODE_PRIVATE)

    fun guardar(sesion: Sesion) {
        prefs.edit()
            .putString("usuario", sesion.usuario)
            .putString("nombre", sesion.nombre)
            .putString("rol", sesion.rol.name)
            .apply()
    }

    fun obtener(): Sesion? {
        val usuario = prefs.getString("usuario", null) ?: return null
        val nombre = prefs.getString("nombre", null) ?: return null
        val rol = prefs.getString("rol", null) ?: return null
        return Sesion(usuario, nombre, Rol.valueOf(rol))
    }

    fun cerrar() = prefs.edit().clear().apply()
}
