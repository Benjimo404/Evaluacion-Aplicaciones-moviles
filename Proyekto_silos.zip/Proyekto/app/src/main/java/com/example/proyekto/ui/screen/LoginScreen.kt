package com.example.proyekto.ui.screen

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.proyekto.model.Sesion
import com.example.proyekto.ui.components.CampoTexto
import com.example.proyekto.viewmodel.LoginViewModel

@Composable
fun LoginScreen(onIngresar: (Sesion) -> Unit, vm: LoginViewModel = viewModel()) {
    val estado by vm.estado.collectAsStateWithLifecycle()

    Box(
        Modifier.fillMaxSize().padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.widthIn(max = 420.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Monitoreo de silos", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Ingresa con tu usuario para ver el estado del alimento en las granjas",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))

            CampoTexto(
                label = "Usuario",
                value = estado.usuario,
                error = estado.errorUsuario,
                icono = Icons.Default.Person,
                onChange = vm::onUsuario
            )
            CampoTexto(
                label = "Clave",
                value = estado.clave,
                error = estado.errorClave,
                icono = Icons.Default.Lock,
                onChange = vm::onClave,
                tipo = KeyboardType.Password,
                visual = if (estado.mostrarClave) VisualTransformation.None else PasswordVisualTransformation(),
                extraFinal = {
                    IconButton(onClick = vm::alternarClave) {
                        Icon(
                            if (estado.mostrarClave) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Mostrar u ocultar clave"
                        )
                    }
                }
            )

            AnimatedVisibility(visible = estado.errorGeneral != null) {
                Text(estado.errorGeneral ?: "", color = MaterialTheme.colorScheme.error)
            }

            Button(
                onClick = { vm.ingresar(onIngresar) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Ingresar") }

            Spacer(Modifier.height(8.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Usuarios de prueba", style = MaterialTheme.typography.labelLarge)
                    Text("operario1 / supervisor1 / jefatura1", style = MaterialTheme.typography.bodySmall)
                    Text("Clave para todos: clave123", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
