package com.example.proyekto.ui.screen

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.proyekto.data.local.AlertaEntity
import com.example.proyekto.model.EstadoSilo
import com.example.proyekto.model.Sesion
import com.example.proyekto.ui.Rutas
import com.example.proyekto.ui.components.EstructuraPrincipal
import com.example.proyekto.ui.components.colorEstado
import com.example.proyekto.util.Formatos
import com.example.proyekto.viewmodel.SiloViewModel

@Composable
fun AlertasScreen(
    sesion: Sesion,
    vm: SiloViewModel,
    onIr: (String) -> Unit,
    onSalir: () -> Unit,
    onAbrirSilo: (String) -> Unit
) {
    val alertas by vm.alertas.collectAsStateWithLifecycle()
    val sinLeer by vm.alertasSinLeer.collectAsStateWithLifecycle()

    EstructuraPrincipal(
        titulo = "Alertas",
        rutaActual = Rutas.ALERTAS,
        sesion = sesion,
        alertasSinLeer = sinLeer,
        onIr = onIr,
        onSalir = onSalir,
        snackbarHostState = remember { SnackbarHostState() },
        acciones = {
            if (sinLeer > 0) {
                IconButton(onClick = vm::marcarTodasLeidas) {
                    Icon(Icons.Default.DoneAll, contentDescription = "Marcar todas como leídas")
                }
            }
        }
    ) { padding ->
        if (alertas.isEmpty()) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No hay alertas por ahora", modifier = Modifier.padding(24.dp))
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 340.dp),
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(alertas, key = { it.id }) { alerta ->
                    AlertaCard(
                        alerta = alerta,
                        onLeida = { vm.marcarLeida(alerta.id) },
                        onVer = { onAbrirSilo(alerta.siloId) },
                        modifier = Modifier.animateItem()
                    )
                }
            }
        }
    }
}

@Composable
private fun AlertaCard(alerta: AlertaEntity, onLeida: () -> Unit, onVer: () -> Unit, modifier: Modifier = Modifier) {
    val estado = EstadoSilo.valueOf(alerta.estado)
    // las no leidas se ven con otro color de fondo
    val fondo by animateColorAsState(
        if (alerta.leida) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.secondaryContainer,
        label = "fondoAlerta"
    )

    Card(modifier = modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = fondo)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (estado == EstadoSilo.CRITICO) Icons.Default.Error else Icons.Default.Warning,
                    contentDescription = null,
                    tint = colorEstado(estado)
                )
                Spacer(Modifier.width(8.dp))
                Text(alerta.siloNombre, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
            }
            Text(alerta.mensaje, style = MaterialTheme.typography.bodyMedium)
            Text(Formatos.fechaHora(alerta.fecha), style = MaterialTheme.typography.labelSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onVer) { Text("Ver silo") }
                if (!alerta.leida) {
                    TextButton(onClick = onLeida) { Text("Marcar como leída") }
                }
            }
        }
    }
}
