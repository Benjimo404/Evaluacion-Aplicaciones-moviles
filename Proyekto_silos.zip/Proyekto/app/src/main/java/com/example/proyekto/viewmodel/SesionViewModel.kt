package com.example.proyekto.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.proyekto.ProyektoApp
import com.example.proyekto.model.Sesion
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SesionViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = (app as ProyektoApp).sesionRepositorio

    private val _sesion = MutableStateFlow(repo.obtener())
    val sesion: StateFlow<Sesion?> = _sesion.asStateFlow()

    fun iniciar(sesion: Sesion) {
        repo.guardar(sesion)
        _sesion.value = sesion
    }

    fun cerrar() {
        repo.cerrar()
        _sesion.value = null
    }
}
