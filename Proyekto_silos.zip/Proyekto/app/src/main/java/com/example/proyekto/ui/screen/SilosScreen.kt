package com.example.proyekto.ui.screen

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.proyekto.data.local.SiloEntity
import com.example.proyekto.data.local.estado
import com.example.proyekto.data.local.porcentaje
import com.example.proyekto.model.Sesion
import com.example.proyekto.ui.Rutas
import com.example.proyekto.ui.components.BarraNivel
import com.example.proyekto.ui.components.EstadoChip
import com.example.proyekto.ui.components.EstructuraPrincipal
import com.example.proyekto.util.Formatos
import com.example.proyekto.viewmodel.SiloViewModel

@Composable
fun SilosScreen(
    sesion: Sesion,
    vm: SiloViewModel,
    onIr: (String) -> Unit,
    onSalir: () -> Unit,
    onAbrirSilo: (String) -> Unit
) {
    val silos by vm.silos.collectAsStateWithLifecycle()
    val granjas by vm.granjas.collectAsStateWithLifecycle()
    val filtro by vm.filtroGranja.collectAsStateWithLifecycle()
    val actualizando by vm.actualizando.collectAsStateWithLifecycle()
    val sinConexion by vm.sinConexion.collectAsStateWithLifecycle()
    val mensaje by vm.mensaje.collectAsStateWithLifecycle()
    val sinLeer by vm.alertasSinLeer.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    // permiso para las notificaciones (Android 13 en adelante)
    val permisoNotificaciones = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(Unit) {
        vm.iniciarMonitoreo()
        if (Build.VERSION.SDK_INT >= 33) {
            permisoNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    LaunchedEffect(mensaje) {
        mensaje?.let {
            snackbar.showSnackbar(it)
            vm.consumirMensaje()
        }
    }

    EstructuraPrincipal(
        titulo = "Silos",
        rutaActual = Rutas.SILOS,
        sesion = sesion,
        alertasSinLeer = sinLeer,
        onIr = onIr,
        onSalir = onSalir,
        snackbarHostState = snackbar,
        acciones = {
            if (actualizando) {
                CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
            } else {
                IconButton(onClick = vm::refrescar) {
                    Icon(Icons.Default.Refresh, contentDescription = "Actualizar")
                }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(horizontal = 16.dp)) {

            AnimatedVisibility(visible = sinConexion) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CloudOff, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Sin conexión. Se muestran los últimos datos guardados.")
                    }
                }
            }

            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(selected = filtro == null, onClick = { vm.setFiltro(null) }, label = { Text("Todas") })
                granjas.forEach { g ->
                    FilterChip(selected = filtro == g, onClick = { vm.setFiltro(g) }, label = { Text(g) })
                }
            }

            if (silos.isEmpty()) {
                Text(
                    if (actualizando) "Cargando silos..." else "No hay silos para mostrar todavía.",
                    modifier = Modifier.padding(top = 16.dp)
                )
            } else {
                // en celular queda 1 columna, en tablet se acomodan varias
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 320.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(silos, key = { it.id }) { silo ->
                        SiloCard(silo, onClick = { onAbrirSilo(silo.id) }, modifier = Modifier.animateItem())
                    }
                }
            }
        }
    }
}

@Composable
private fun SiloCard(silo: SiloEntity, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(modifier = modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(silo.nombre, style = MaterialTheme.typography.titleMedium)
                    Text(silo.granja, style = MaterialTheme.typography.bodySmall)
                }
                EstadoChip(silo.estado)
            }
            BarraNivel(silo.porcentaje, silo.estado)
            Row {
                Text("${silo.porcentaje}%", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                Text(
                    "${Formatos.kg(silo.nivelKg)} de ${Formatos.kg(silo.capacidadKg)}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Text("Actualizado: ${Formatos.fechaHora(silo.actualizado)}", style = MaterialTheme.typography.labelSmall)
        }
    }
}
