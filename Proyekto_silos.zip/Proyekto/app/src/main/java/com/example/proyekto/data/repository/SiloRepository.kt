package com.example.proyekto.data.repository

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.proyekto.data.local.AlertaEntity
import com.example.proyekto.data.local.AppDatabase
import com.example.proyekto.data.local.HistorialEntity
import com.example.proyekto.data.local.MovimientoEntity
import com.example.proyekto.data.local.SiloEntity
import com.example.proyekto.data.local.estado
import com.example.proyekto.data.local.porcentaje
import com.example.proyekto.data.remote.MovimientoDto
import com.example.proyekto.data.remote.SiloApi
import com.example.proyekto.model.EstadoSilo
import com.example.proyekto.model.TipoMovimiento
import kotlinx.coroutines.flow.Flow

data class ResultadoRefresco(
    val exito: Boolean,
    val alertasNuevas: List<AlertaEntity> = emptyList(),
    val error: String? = null
)

class SiloRepository(
    private val context: Context,
    db: AppDatabase,
    private val api: SiloApi
) {
    private val siloDao = db.siloDao()
    private val movimientoDao = db.movimientoDao()
    private val historialDao = db.historialDao()
    private val alertaDao = db.alertaDao()

    // lo que se muestra sale siempre de Room, asi funciona sin internet
    val silos: Flow<List<SiloEntity>> = siloDao.observarTodos()
    val alertas: Flow<List<AlertaEntity>> = alertaDao.observarTodas()
    val alertasSinLeer: Flow<Int> = alertaDao.contarNoLeidas()

    fun silo(id: String) = siloDao.observarPorId(id)
    fun movimientos(id: String) = movimientoDao.observarPorSilo(id)
    fun historial(id: String) = historialDao.observarPorSilo(id)
    suspend fun obtenerSilo(id: String) = siloDao.obtenerPorId(id)

    fun hayConexion(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val red = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(red) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    suspend fun refrescar(): ResultadoRefresco {
        if (!hayConexion()) {
            return ResultadoRefresco(false, error = "Sin conexión, mostrando los últimos datos guardados")
        }
        return try {
            enviarPendientes()
            val nuevas = mutableListOf<AlertaEntity>()
            for (dto in api.obtenerSilos()) {
                val anterior = siloDao.obtenerPorId(dto.id)
                // los umbrales los configura el supervisor, asi que se mantienen los locales
                val silo = SiloEntity(
                    id = dto.id,
                    granja = dto.granja,
                    nombre = dto.nombre,
                    capacidadKg = dto.capacidadKg,
                    nivelKg = dto.nivelKg,
                    consumoDiarioKg = dto.consumoDiarioKg,
                    tipoAlimento = dto.tipoAlimento,
                    estadoOperativo = dto.estadoOperativo,
                    umbralAdvertencia = anterior?.umbralAdvertencia ?: 30,
                    umbralCritico = anterior?.umbralCritico ?: 20,
                    actualizado = dto.actualizado
                )
                siloDao.guardar(silo)
                generarAlerta(anterior, silo)?.let { nuevas.add(it) }
            }
            ResultadoRefresco(true, nuevas)
        } catch (e: Exception) {
            ResultadoRefresco(false, error = "No se pudo actualizar, intenta de nuevo")
        }
    }

    suspend fun cargarHistorial(id: String) {
        if (!hayConexion()) return
        try {
            val lecturas = api.obtenerHistorial(id)
            historialDao.borrarPorSilo(id)
            historialDao.insertarTodos(lecturas.map { HistorialEntity(siloId = id, nivelKg = it.nivelKg, fecha = it.fecha) })
        } catch (e: Exception) {
            // si falla se queda con lo que ya habia guardado
        }
    }

    // devuelve la alerta si el silo quedo en un estado peor que antes
    suspend fun registrarMovimiento(
        silo: SiloEntity,
        tipo: TipoMovimiento,
        cantidadKg: Double,
        observacion: String,
        fotoUri: String?
    ): AlertaEntity? {
        val nuevoNivel = when {
            !tipo.afectaNivel -> silo.nivelKg // las incidencias solo se reportan
            tipo.aumentaNivel -> silo.nivelKg + cantidadKg
            else -> silo.nivelKg - cantidadKg
        }
        val actualizado = silo.copy(nivelKg = nuevoNivel, actualizado = System.currentTimeMillis())
        siloDao.guardar(actualizado)

        val idMov = movimientoDao.insertar(
            MovimientoEntity(
                siloId = silo.id,
                tipo = tipo.name,
                cantidadKg = cantidadKg,
                observacion = observacion,
                fotoUri = fotoUri,
                fecha = System.currentTimeMillis()
            )
        )
        // si no hay internet queda pendiente y se manda en el proximo refresco
        if (hayConexion()) {
            try {
                api.enviarMovimiento(silo.id, MovimientoDto(tipo.name, cantidadKg, System.currentTimeMillis()))
                movimientoDao.marcarSincronizado(idMov)
            } catch (e: Exception) {
            }
        }
        return generarAlerta(silo, actualizado)
    }

    suspend fun actualizarUmbrales(id: String, advertencia: Int, critico: Int) =
        siloDao.actualizarUmbrales(id, advertencia, critico)

    suspend fun marcarAlertaLeida(id: Long) = alertaDao.marcarLeida(id)
    suspend fun marcarTodasLeidas() = alertaDao.marcarTodasLeidas()

    private suspend fun enviarPendientes() {
        for (mov in movimientoDao.pendientes()) {
            api.enviarMovimiento(mov.siloId, MovimientoDto(mov.tipo, mov.cantidadKg, mov.fecha))
            movimientoDao.marcarSincronizado(mov.id)
        }
    }

    private suspend fun generarAlerta(antes: SiloEntity?, ahora: SiloEntity): AlertaEntity? {
        val estado = ahora.estado
        // solo se avisa cuando el silo empeora (normal -> advertencia -> critico)
        val estadoAntes = antes?.estado ?: EstadoSilo.NORMAL
        if (estado.ordinal <= estadoAntes.ordinal) return null

        val texto = if (estado == EstadoSilo.CRITICO) "en nivel CRÍTICO" else "en nivel de advertencia"
        val alerta = AlertaEntity(
            siloId = ahora.id,
            siloNombre = "${ahora.nombre} - ${ahora.granja}",
            estado = estado.name,
            mensaje = "${ahora.nombre} (${ahora.granja}) está $texto: ${ahora.porcentaje}% de su capacidad. Se requiere reposición.",
            fecha = System.currentTimeMillis()
        )
        val id = alertaDao.insertar(alerta)
        return alerta.copy(id = id)
    }
}
