package com.example.proyekto.ui

object Rutas {
    const val LOGIN = "login"
    const val SILOS = "silos"
    const val ALERTAS = "alertas"
    const val RESUMEN = "resumen"
    const val DETALLE = "detalle/{id}"
    const val MOVIMIENTO = "movimiento/{id}"
    const val UMBRAL = "umbral/{id}"

    fun detalle(id: String) = "detalle/$id"
    fun movimiento(id: String) = "movimiento/$id"
    fun umbral(id: String) = "umbral/$id"
}
