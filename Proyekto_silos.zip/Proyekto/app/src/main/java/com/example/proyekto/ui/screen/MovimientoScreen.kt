package com.example.proyekto.ui.screen

import android.Manifest
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.proyekto.model.Rol
import com.example.proyekto.model.TipoMovimiento
import com.example.proyekto.ui.components.CampoTexto
import com.example.proyekto.util.Formatos
import com.example.proyekto.util.crearUriFoto
import com.example.proyekto.viewmodel.MovimientoViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MovimientoScreen(siloId: String, rol: Rol, vm: MovimientoViewModel, onVolver: () -> Unit) {
    val form by vm.form.collectAsStateWithLifecycle()
    val silo by vm.silo.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var uriTemporal by remember { mutableStateOf<Uri?>(null) }

    // la confirmacion de reposiciones es del supervisor, el operario no la ve
    val tipos = TipoMovimiento.entries.filter { rol == Rol.SUPERVISOR || it != TipoMovimiento.REPOSICION }
    val esIncidencia = form.tipo == TipoMovimiento.INCIDENCIA

    LaunchedEffect(siloId) { vm.cargar(siloId) }

    val volver = { vm.limpiar(); onVolver() }
    BackHandler { volver() }

    // camara: primero se pide el permiso y despues se abre
    val camara = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) vm.onFoto(uriTemporal.toString())
    }
    val permisoCamara = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { concedido ->
        if (concedido) {
            val uri = crearUriFoto(context)
            uriTemporal = uri
            camara.launch(uri)
        } else {
            Toast.makeText(context, "Sin permiso de cámara no se puede tomar la foto", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (esIncidencia) "Reportar incidencia" else "Registrar movimiento") },
                navigationIcon = {
                    IconButton(onClick = { volver() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                silo?.let { s ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${s.nombre} - ${s.granja}", style = MaterialTheme.typography.titleMedium)
                            Text("Nivel actual: ${Formatos.kg(s.nivelKg)}", style = MaterialTheme.typography.bodySmall)
                            Text(
                                "Espacio libre: ${Formatos.kg(s.capacidadKg - s.nivelKg)}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                Text("Tipo de movimiento", style = MaterialTheme.typography.labelLarge)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    tipos.forEach { t ->
                        FilterChip(
                            selected = form.tipo == t,
                            onClick = { vm.onTipo(t) },
                            label = { Text(t.etiqueta) }
                        )
                    }
                }

                // en una incidencia no se ingresa cantidad
                AnimatedVisibility(visible = !esIncidencia) {
                    CampoTexto(
                        label = "Cantidad",
                        value = form.cantidad,
                        error = form.errorCantidad,
                        icono = Icons.Default.Info,
                        onChange = vm::onCantidad,
                        tipo = KeyboardType.Decimal,
                        sufijo = "kg"
                    )
                }
                CampoTexto(
                    label = if (esIncidencia) "Descripción de la incidencia" else "Observación (opcional)",
                    value = form.observacion,
                    error = form.errorObservacion,
                    icono = Icons.Default.Edit,
                    onChange = vm::onObservacion
                )

                OutlinedButton(
                    onClick = { permisoCamara.launch(Manifest.permission.CAMERA) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (form.fotoUri == null) "Adjuntar foto (opcional)" else "Cambiar foto")
                }

                AnimatedVisibility(visible = form.fotoUri != null) {
                    AsyncImage(
                        model = form.fotoUri,
                        contentDescription = "Foto del movimiento",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )
                }

                Button(
                    onClick = {
                        vm.guardar {
                            Toast.makeText(context, "Movimiento registrado", Toast.LENGTH_SHORT).show()
                            onVolver()
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Guardar movimiento") }
            }
        }
    }
}
