package com.example.proyekto.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.proyekto.data.local.HistorialEntity
import com.example.proyekto.data.local.MovimientoEntity
import com.example.proyekto.data.local.SiloEntity
import com.example.proyekto.data.local.diasRestantes
import com.example.proyekto.data.local.estado
import com.example.proyekto.data.local.porcentaje
import com.example.proyekto.model.Rol
import com.example.proyekto.model.Sesion
import com.example.proyekto.model.TipoMovimiento
import com.example.proyekto.ui.components.BarraNivel
import com.example.proyekto.ui.components.EstadoChip
import com.example.proyekto.ui.components.GraficoBarras
import com.example.proyekto.ui.components.colorEstado
import com.example.proyekto.util.Formatos
import com.example.proyekto.viewmodel.SiloViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetalleSiloScreen(
    siloId: String,
    sesion: Sesion,
    vm: SiloViewModel,
    onVolver: () -> Unit,
    onMovimiento: () -> Unit,
    onUmbral: () -> Unit
) {
    val silo by remember(siloId) { vm.observarSilo(siloId) }
        .collectAsStateWithLifecycle(initialValue = null)
    val historial by remember(siloId) { vm.observarHistorial(siloId) }
        .collectAsStateWithLifecycle(initialValue = emptyList())
    val movimientos by remember(siloId) { vm.observarMovimientos(siloId) }
        .collectAsStateWithLifecycle(initialValue = emptyList())

    // pide el historial a la API cada vez que se entra al detalle
    LaunchedEffect(siloId) { vm.cargarHistorial(siloId) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(silo?.nombre ?: "Detalle del silo") },
                navigationIcon = {
                    IconButton(onClick = onVolver) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        val s = silo
        if (s == null) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        // pantalla grande: info a la izquierda y movimientos a la derecha
        BoxWithConstraints(Modifier.padding(padding).fillMaxSize()) {
            if (maxWidth < 700.dp) {
                Column(
                    Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    InfoSilo(s)
                    PanelHistorial(s, historial)
                    Acciones(sesion, onMovimiento, onUmbral)
                    PanelMovimientos(movimientos)
                }
            } else {
                Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    Column(
                        Modifier.weight(1f).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        InfoSilo(s)
                        PanelHistorial(s, historial)
                    }
                    Column(
                        Modifier.weight(1f).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Acciones(sesion, onMovimiento, onUmbral)
                        PanelMovimientos(movimientos)
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoSilo(s: SiloEntity) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(s.granja, style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "${s.porcentaje}%",
                        style = MaterialTheme.typography.displaySmall,
                        color = colorEstado(s.estado)
                    )
                }
                EstadoChip(s.estado)
            }
            BarraNivel(s.porcentaje, s.estado)
            Text("Tipo de alimento: ${s.tipoAlimento}")
            Text("Estado operativo: ${s.estadoOperativo}")
            Text("Nivel actual: ${Formatos.kg(s.nivelKg)}")
            Text("Capacidad total: ${Formatos.kg(s.capacidadKg)}")
            Text("Consumo diario estimado: ${Formatos.kg(s.consumoDiarioKg)}")
            Text("Alimento para aprox. ${"%.1f".format(s.diasRestantes)} días")
            Text(
                "Alertas: advertencia hasta ${s.umbralAdvertencia}%, crítico bajo ${s.umbralCritico}%",
                style = MaterialTheme.typography.bodySmall
            )
            Text("Última actualización: ${Formatos.fechaHora(s.actualizado)}", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun PanelHistorial(s: SiloEntity, historial: List<HistorialEntity>) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Historial de nivel (últimos días)", style = MaterialTheme.typography.titleMedium)
            if (historial.isEmpty()) {
                Text("Todavía no hay historial guardado para este silo.", style = MaterialTheme.typography.bodySmall)
            } else {
                GraficoBarras(
                    valores = historial.map { (it.nivelKg / s.capacidadKg).toFloat() },
                    etiquetas = historial.map { Formatos.dia(it.fecha) },
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun Acciones(sesion: Sesion, onMovimiento: () -> Unit, onUmbral: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // la jefatura solo consulta, no registra movimientos
        if (sesion.rol != Rol.JEFATURA) {
            Button(onClick = onMovimiento, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Edit, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Registrar movimiento")
            }
        }
        if (sesion.rol == Rol.SUPERVISOR) {
            OutlinedButton(onClick = onUmbral, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Notifications, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Configurar niveles de alerta")
            }
        }
    }
}

@Composable
private fun PanelMovimientos(movimientos: List<MovimientoEntity>) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Últimos movimientos", style = MaterialTheme.typography.titleMedium)
            if (movimientos.isEmpty()) {
                Text("Aún no se registran movimientos.", style = MaterialTheme.typography.bodySmall)
            }
            movimientos.take(8).forEach { m ->
                Row {
                    Column(Modifier.weight(1f)) {
                        Text(TipoMovimiento.valueOf(m.tipo).etiqueta, style = MaterialTheme.typography.bodyMedium)
                        if (m.observacion.isNotBlank()) {
                            Text(m.observacion, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(
                            Formatos.fechaHora(m.fecha) + if (m.sincronizado) "" else " · pendiente de enviar",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                    if (TipoMovimiento.valueOf(m.tipo).afectaNivel) {
                        Text(Formatos.kg(m.cantidadKg), style = MaterialTheme.typography.bodyMedium)
                    }
                }
                HorizontalDivider()
            }
        }
    }
}
