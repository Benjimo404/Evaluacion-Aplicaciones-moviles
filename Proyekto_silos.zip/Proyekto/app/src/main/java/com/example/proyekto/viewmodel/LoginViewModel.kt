package com.example.proyekto.viewmodel

import androidx.lifecycle.ViewModel
import com.example.proyekto.data.repository.UsuariosDemo
import com.example.proyekto.model.Sesion
import com.example.proyekto.validacion.ValidadorLogin
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class LoginState(
    val usuario: String = "",
    val clave: String = "",
    val mostrarClave: Boolean = false,
    val errorUsuario: String? = null,
    val errorClave: String? = null,
    val errorGeneral: String? = null
)

class LoginViewModel : ViewModel() {

    private val _estado = MutableStateFlow(LoginState())
    val estado: StateFlow<LoginState> = _estado.asStateFlow()

    fun onUsuario(v: String) = _estado.update {
        it.copy(usuario = v, errorUsuario = ValidadorLogin.usuario(v), errorGeneral = null)
    }

    fun onClave(v: String) = _estado.update {
        it.copy(clave = v, errorClave = ValidadorLogin.clave(v), errorGeneral = null)
    }

    fun alternarClave() = _estado.update { it.copy(mostrarClave = !it.mostrarClave) }

    fun ingresar(onExito: (Sesion) -> Unit) {
        val e = _estado.value
        val errorUsuario = ValidadorLogin.usuario(e.usuario)
        val errorClave = ValidadorLogin.clave(e.clave)
        if (errorUsuario != null || errorClave != null) {
            _estado.update { it.copy(errorUsuario = errorUsuario, errorClave = errorClave) }
            return
        }

        val sesion = UsuariosDemo.autenticar(e.usuario, e.clave)
        if (sesion == null) {
            _estado.update { it.copy(errorGeneral = "Usuario o clave incorrectos") }
        } else {
            _estado.value = LoginState()
            onExito(sesion)
        }
    }
}
