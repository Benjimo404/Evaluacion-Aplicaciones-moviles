package com.example.proyekto.ui.screen

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.proyekto.ui.components.CampoTexto
import com.example.proyekto.viewmodel.UmbralViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UmbralScreen(siloId: String, vm: UmbralViewModel, onVolver: () -> Unit) {
    val form by vm.form.collectAsStateWithLifecycle()
    val silo by vm.silo.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(siloId) { vm.cargar(siloId) }

    val volver = { vm.limpiar(); onVolver() }
    BackHandler { volver() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Niveles de alerta") },
                navigationIcon = {
                    IconButton(onClick = { volver() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    silo?.let { "${it.nombre} - ${it.granja}" } ?: "",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    "Por defecto el silo está en advertencia entre 20% y 30%, y en estado crítico bajo 20%. " +
                        "Aquí se pueden cambiar esos porcentajes. Cuando el silo empeora de estado se genera una alerta y una notificación.",
                    style = MaterialTheme.typography.bodyMedium
                )

                CampoTexto(
                    label = "Advertencia (hasta)",
                    value = form.advertencia,
                    error = form.errorAdvertencia,
                    icono = Icons.Default.Notifications,
                    onChange = vm::onAdvertencia,
                    tipo = KeyboardType.Number,
                    sufijo = "%"
                )
                CampoTexto(
                    label = "Crítico (bajo)",
                    value = form.critico,
                    error = form.errorCritico,
                    icono = Icons.Default.Warning,
                    onChange = vm::onCritico,
                    tipo = KeyboardType.Number,
                    sufijo = "%"
                )

                Button(
                    onClick = {
                        vm.guardar {
                            Toast.makeText(context, "Niveles actualizados", Toast.LENGTH_SHORT).show()
                            onVolver()
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Guardar") }
            }
        }
    }
}
