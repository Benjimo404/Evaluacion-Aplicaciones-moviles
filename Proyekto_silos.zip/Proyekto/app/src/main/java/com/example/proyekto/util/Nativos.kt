package com.example.proyekto.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.proyekto.MainActivity
import com.example.proyekto.data.local.AlertaEntity
import com.example.proyekto.model.EstadoSilo
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// recurso nativo: camara. Crea el archivo donde queda la foto
fun crearUriFoto(context: Context): Uri {
    val carpeta = File(context.filesDir, "fotos").apply { mkdirs() }
    val archivo = File.createTempFile("mov_", ".jpg", carpeta)
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", archivo)
}

// recurso nativo: notificaciones
object Notificaciones {
    private const val CANAL = "alertas_silos"

    fun mostrarAlerta(context: Context, alerta: AlertaEntity) {
        // en Android 13+ hay que tener el permiso, si no se ignora
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(
            NotificationChannel(CANAL, "Alertas de silos", NotificationManager.IMPORTANCE_HIGH)
        )

        val titulo = if (alerta.estado == EstadoSilo.CRITICO.name) "Silo en nivel crítico" else "Silo con nivel bajo"
        val abrirApp = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notificacion = NotificationCompat.Builder(context, CANAL)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(titulo)
            .setContentText(alerta.mensaje)
            .setStyle(NotificationCompat.BigTextStyle().bigText(alerta.mensaje))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(abrirApp)
            .setAutoCancel(true)
            .build()
        manager.notify(alerta.id.toInt(), notificacion)
    }
}

object Formatos {
    fun kg(valor: Double): String = "%,.0f kg".format(valor)

    fun fechaHora(millis: Long): String =
        SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(millis))

    fun dia(millis: Long): String =
        SimpleDateFormat("dd/MM", Locale.getDefault()).format(Date(millis))
}
