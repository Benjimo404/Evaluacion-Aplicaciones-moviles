package com.example.proyekto.ui.screen

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.proyekto.data.local.SiloEntity
import com.example.proyekto.data.local.diasRestantes
import com.example.proyekto.data.local.estado
import com.example.proyekto.data.local.porcentaje
import com.example.proyekto.model.EstadoSilo
import com.example.proyekto.model.Sesion
import com.example.proyekto.ui.Rutas
import com.example.proyekto.ui.components.BarraNivel
import com.example.proyekto.ui.components.EstructuraPrincipal
import com.example.proyekto.ui.components.colorEstado
import com.example.proyekto.util.Formatos
import com.example.proyekto.viewmodel.ResumenGranja
import com.example.proyekto.viewmodel.SiloViewModel

// pantalla de la jefatura: resumen por granja y orden de reposicion
@Composable
fun ResumenScreen(
    sesion: Sesion,
    vm: SiloViewModel,
    onIr: (String) -> Unit,
    onSalir: () -> Unit,
    onAbrirSilo: (String) -> Unit
) {
    val resumen by vm.resumen.collectAsStateWithLifecycle()
    val reposiciones by vm.reposiciones.collectAsStateWithLifecycle()
    val sinLeer by vm.alertasSinLeer.collectAsStateWithLifecycle()

    EstructuraPrincipal(
        titulo = "Resumen",
        rutaActual = Rutas.RESUMEN,
        sesion = sesion,
        alertasSinLeer = sinLeer,
        onIr = onIr,
        onSalir = onSalir,
        snackbarHostState = remember { SnackbarHostState() }
    ) { padding ->
        BoxWithConstraints(Modifier.padding(padding).fillMaxSize()) {
            if (maxWidth < 700.dp) {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { Text("Por granja", style = MaterialTheme.typography.titleMedium) }
                    items(resumen, key = { it.granja }) { ResumenCard(it) }
                    item { Text("Plan de reposición", style = MaterialTheme.typography.titleMedium) }
                    items(reposiciones, key = { it.id }) { ReposicionItem(it) { onAbrirSilo(it.id) } }
                }
            } else {
                Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item { Text("Por granja", style = MaterialTheme.typography.titleMedium) }
                        items(resumen, key = { it.granja }) { ResumenCard(it) }
                    }
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item { Text("Plan de reposición", style = MaterialTheme.typography.titleMedium) }
                        items(reposiciones, key = { it.id }) { ReposicionItem(it) { onAbrirSilo(it.id) } }
                    }
                }
            }
        }
    }
}

@Composable
private fun ResumenCard(r: ResumenGranja) {
    val estado = when {
        r.criticos > 0 -> EstadoSilo.CRITICO
        r.porcentaje <= 30 -> EstadoSilo.ADVERTENCIA
        else -> EstadoSilo.NORMAL
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(r.granja, style = MaterialTheme.typography.titleSmall)
            BarraNivel(r.porcentaje, estado)
            Text("${r.porcentaje}% · ${Formatos.kg(r.nivelKg)} de ${Formatos.kg(r.capacidadKg)}")
            Text(
                "${r.cantidadSilos} silos · consumo diario ${Formatos.kg(r.consumoDiarioKg)}",
                style = MaterialTheme.typography.bodySmall
            )
            if (r.criticos > 0) {
                Text(
                    "${r.criticos} silo(s) en nivel crítico",
                    color = colorEstado(EstadoSilo.CRITICO),
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
private fun ReposicionItem(silo: SiloEntity, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("${silo.nombre} - ${silo.granja}", style = MaterialTheme.typography.titleSmall)
                Text("${silo.porcentaje}% de capacidad", style = MaterialTheme.typography.bodySmall)
            }
            Text(
                "~${"%.1f".format(silo.diasRestantes)} días",
                color = colorEstado(silo.estado),
                style = MaterialTheme.typography.titleSmall
            )
        }
    }
}
