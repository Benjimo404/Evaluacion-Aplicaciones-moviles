package com.example.proyekto.data.remote

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

data class SiloDto(
    val id: String,
    val granja: String,
    val nombre: String,
    val capacidadKg: Double,
    val nivelKg: Double,
    val consumoDiarioKg: Double,
    val tipoAlimento: String,
    val estadoOperativo: String,
    val actualizado: Long
)

data class LecturaDto(
    val nivelKg: Double,
    val fecha: Long
)

data class MovimientoDto(
    val tipo: String,
    val cantidadKg: Double,
    val fecha: Long
)

data class RespuestaDto(
    val ok: Boolean,
    val nivelKg: Double
)

interface SiloApi {

    @GET("silos")
    suspend fun obtenerSilos(): List<SiloDto>

    @GET("silos/{id}/historial")
    suspend fun obtenerHistorial(@Path("id") id: String): List<LecturaDto>

    @POST("silos/{id}/movimientos")
    suspend fun enviarMovimiento(
        @Path("id") id: String,
        @Body movimiento: MovimientoDto
    ): RespuestaDto
}
