package com.example.proyekto.ui.theme

import androidx.compose.ui.graphics.Color

val Green80 = Color(0xFFA8DAB5)
val GreenGrey80 = Color(0xFFBCCBC0)
val Teal80 = Color(0xFF9CCFD8)

val Green40 = Color(0xFF1B6B3A)
val GreenGrey40 = Color(0xFF506352)
val Teal40 = Color(0xFF2E6A74)

// colores para los estados de los silos
val EstadoNormal = Color(0xFF2E7D32)
val EstadoAdvertencia = Color(0xFFB26A00)
val EstadoCritico = Color(0xFFC62828)
