package com.example.proyekto.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.proyekto.model.EstadoSilo
import kotlin.math.roundToInt

@Entity(tableName = "silos")
data class SiloEntity(
    @PrimaryKey val id: String,
    val granja: String,
    val nombre: String,
    val capacidadKg: Double,
    val nivelKg: Double,
    val consumoDiarioKg: Double,
    val tipoAlimento: String = "",
    val estadoOperativo: String = "Operativo",
    val umbralAdvertencia: Int = 30,
    val umbralCritico: Int = 20,
    val actualizado: Long = System.currentTimeMillis()
)

@Entity(tableName = "movimientos")
data class MovimientoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val siloId: String,
    val tipo: String,          // nombre del enum TipoMovimiento
    val cantidadKg: Double,
    val observacion: String,
    val fotoUri: String? = null,
    val fecha: Long,
    val sincronizado: Boolean = false
)

@Entity(tableName = "historial")
data class HistorialEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val siloId: String,
    val nivelKg: Double,
    val fecha: Long
)

@Entity(tableName = "alertas")
data class AlertaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val siloId: String,
    val siloNombre: String,
    val estado: String,        // nombre del enum EstadoSilo
    val mensaje: String,
    val fecha: Long,
    val leida: Boolean = false
)

// Niveles segun el caso: normal sobre 30%, advertencia entre 20% y 30%, critico bajo 20%
// (los dejo fuera de la clase para que Room no se confunda)
val SiloEntity.porcentaje: Int
    get() = if (capacidadKg <= 0) 0
    else ((nivelKg / capacidadKg) * 100).roundToInt().coerceIn(0, 100)

val SiloEntity.estado: EstadoSilo
    get() = when {
        porcentaje < umbralCritico -> EstadoSilo.CRITICO
        porcentaje <= umbralAdvertencia -> EstadoSilo.ADVERTENCIA
        else -> EstadoSilo.NORMAL
    }

val SiloEntity.diasRestantes: Double
    get() = if (consumoDiarioKg <= 0) 99.0 else nivelKg / consumoDiarioKg
