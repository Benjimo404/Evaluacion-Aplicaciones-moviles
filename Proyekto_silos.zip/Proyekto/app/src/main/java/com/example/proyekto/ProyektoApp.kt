package com.example.proyekto

import android.app.Application
import com.example.proyekto.data.local.AppDatabase
import com.example.proyekto.data.remote.ApiClient
import com.example.proyekto.data.repository.SesionRepository
import com.example.proyekto.data.repository.SiloRepository

// aca se crean las dependencias una sola vez para toda la app
class ProyektoApp : Application() {

    val repositorio: SiloRepository by lazy {
        SiloRepository(this, AppDatabase.get(this), ApiClient.api)
    }

    val sesionRepositorio: SesionRepository by lazy { SesionRepository(this) }
}
