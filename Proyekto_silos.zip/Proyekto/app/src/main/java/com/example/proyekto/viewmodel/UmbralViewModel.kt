package com.example.proyekto.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.proyekto.ProyektoApp
import com.example.proyekto.data.local.SiloEntity
import com.example.proyekto.validacion.ValidadorUmbral
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UmbralForm(
    val advertencia: String = "",
    val critico: String = "",
    val errorAdvertencia: String? = null,
    val errorCritico: String? = null
)

class UmbralViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = (app as ProyektoApp).repositorio

    private val _silo = MutableStateFlow<SiloEntity?>(null)
    val silo: StateFlow<SiloEntity?> = _silo.asStateFlow()

    private val _form = MutableStateFlow(UmbralForm())
    val form: StateFlow<UmbralForm> = _form.asStateFlow()

    fun cargar(siloId: String) {
        if (_silo.value?.id == siloId) return
        viewModelScope.launch {
            val s = repo.obtenerSilo(siloId) ?: return@launch
            _silo.value = s
            _form.value = UmbralForm(
                advertencia = s.umbralAdvertencia.toString(),
                critico = s.umbralCritico.toString()
            )
        }
    }

    fun onAdvertencia(v: String) = _form.update {
        it.copy(
            advertencia = v,
            errorAdvertencia = ValidadorUmbral.advertencia(v),
            // el critico depende de este valor, asi que se revisa de nuevo
            errorCritico = if (it.critico.isBlank()) null else ValidadorUmbral.critico(it.critico, v)
        )
    }

    fun onCritico(v: String) = _form.update {
        it.copy(critico = v, errorCritico = ValidadorUmbral.critico(v, it.advertencia))
    }

    fun limpiar() {
        _silo.value = null
        _form.value = UmbralForm()
    }

    fun guardar(onExito: () -> Unit) {
        val f = _form.value
        val silo = _silo.value ?: return
        val errorAdv = ValidadorUmbral.advertencia(f.advertencia)
        val errorCrit = ValidadorUmbral.critico(f.critico, f.advertencia)
        if (errorAdv != null || errorCrit != null) {
            _form.update { it.copy(errorAdvertencia = errorAdv, errorCritico = errorCrit) }
            return
        }
        viewModelScope.launch {
            repo.actualizarUmbrales(silo.id, f.advertencia.toInt(), f.critico.toInt())
            limpiar()
            onExito()
        }
    }
}
