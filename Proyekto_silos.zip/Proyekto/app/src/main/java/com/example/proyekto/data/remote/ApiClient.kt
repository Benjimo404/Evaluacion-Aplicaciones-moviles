package com.example.proyekto.data.remote

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiClient {

    // Si algun dia hay una API real: cambiar esta URL y sacar el addInterceptor
    private const val BASE_URL = "https://api.silos-simulada.cl/"

    val api: SiloApi by lazy {
        val cliente = OkHttpClient.Builder()
            .addInterceptor(SimuladorInterceptor())
            .build()

        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(cliente)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(SiloApi::class.java)
    }
}
