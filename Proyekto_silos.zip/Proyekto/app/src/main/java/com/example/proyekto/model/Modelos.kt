package com.example.proyekto.model

enum class Rol(val titulo: String) {
    OPERARIO("Operario"),
    SUPERVISOR("Supervisor"),
    JEFATURA("Jefatura")
}

enum class EstadoSilo(val etiqueta: String) {
    NORMAL("Normal"),
    ADVERTENCIA("Advertencia"),
    CRITICO("Crítico")
}

// aumentaNivel: suma al silo. afectaNivel: false cuando solo es un reporte (incidencia)
enum class TipoMovimiento(val etiqueta: String, val aumentaNivel: Boolean, val afectaNivel: Boolean) {
    CARGA("Carga", true, true),
    DESCARGA("Descarga", false, true),
    CONSUMO("Consumo", false, true),
    REPOSICION("Reposición confirmada", true, true),
    INCIDENCIA("Incidencia", false, false)
}

data class Sesion(
    val usuario: String,
    val nombre: String,
    val rol: Rol
)
