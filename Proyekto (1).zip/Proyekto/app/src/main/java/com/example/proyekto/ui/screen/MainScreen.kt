package com.example.proyekto.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.proyekto.viewmodel.MainViewModel

@Composable
@Preview(widthDp = 700, heightDp = 800)
fun MainScreen(
    viewModel: MainViewModel = viewModel()
) {
    val bici by viewModel.bicicleta.collectAsStateWithLifecycle()

    BoxWithConstraints(
        modifier = Modifier.fillMaxSize()
    ) {
        if (maxWidth < 600.dp) {
            // Pantalla pequeña (Diseño Vertical)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
            ) {
                Text(
                    text = "Bicicleta: ${bici.marca} (${bici.codigo})",
                    style = MaterialTheme.typography.headlineMedium
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Cobro estimado: $${bici.calcularCobro()}",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        } else {
            // Pantalla grande (Diseño Horizontal)
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
            ) {
                Text(
                    text = "Bicicleta: ${bici.marca} (${bici.codigo})",
                    style = MaterialTheme.typography.headlineMedium
                )
                Spacer(modifier = Modifier.width(32.dp))
                Text(
                    text = "Cobro estimado: $${bici.calcularCobro()}",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}