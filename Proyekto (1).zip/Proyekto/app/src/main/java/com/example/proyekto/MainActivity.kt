package com.example.proyekto

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.proyekto.ui.screen.MainScreen
import com.example.proyekto.ui.theme.ProyektoTheme
import com.example.proyekto.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ProyektoTheme {
                val viewModel: MainViewModel = viewModel ()
                MainScreen(
                    viewModel = viewModel
                )
            }
        }
    }
}