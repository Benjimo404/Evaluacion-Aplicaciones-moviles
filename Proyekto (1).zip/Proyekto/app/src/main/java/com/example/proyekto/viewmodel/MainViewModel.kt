package com.example.proyekto.viewmodel

import androidx.lifecycle.ViewModel
import com.example.proyekto.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDateTime

class MainViewModel : ViewModel() {
    private val _bicicleta = MutableStateFlow<Bicicleta>(
        BicicletaEstandar(
            codigo = "BICI-001",
            marca = "Trek",
            fecha = LocalDateTime.now().minusHours(2),
            tipoUsuario = TipoUsuario.ABONADO
        )
    )
    val bicicleta = _bicicleta.asStateFlow()
}