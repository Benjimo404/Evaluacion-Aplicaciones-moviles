package com.example.proyekto.model

import java.time.Duration
import java.time.LocalDateTime

enum class TipoUsuario {
    REGULAR, ABONADO, ESTUDIANTE
}

abstract class Bicicleta(
    val codigo: String,
    val marca: String,
    val fecha: LocalDateTime,
    val tipoUsuario: TipoUsuario
) {
    abstract fun calcularCobro(): Int
}

class BicicletaEstandar(
    codigo: String,
    marca: String,
    fecha: LocalDateTime,
    tipoUsuario: TipoUsuario
) : Bicicleta(codigo, marca, fecha, tipoUsuario) {

    override fun calcularCobro(): Int {
        val minutos = Duration.between(fecha, LocalDateTime.now()).toMinutes()
        val tarifaHora = if (tipoUsuario == TipoUsuario.ABONADO) 800 else 1000
        return ((minutos / 60.0) * tarifaHora).toInt()
    }
}

class BicicletaElectrica(
    codigo: String,
    marca: String,
    fecha: LocalDateTime,
    tipoUsuario: TipoUsuario
) : Bicicleta(codigo, marca, fecha, tipoUsuario) {

    override fun calcularCobro(): Int {
        val minutos = Duration.between(fecha, LocalDateTime.now()).toMinutes()
        return if (minutos < 20) {
            500
        } else {
            ((minutos / 60.0) * 1800).toInt()
        }
    }
}

class BicicletaCarga(
    val capacidadExtendida: Boolean,
    codigo: String,
    marca: String,
    fecha: LocalDateTime,
    tipoUsuario: TipoUsuario
) : Bicicleta(codigo, marca, fecha, tipoUsuario) {

    override fun calcularCobro(): Int {
        val minutos = Duration.between(fecha, LocalDateTime.now()).toMinutes()
        val cobroBase = (minutos / 60.0) * 2500
        return if (tipoUsuario == TipoUsuario.ESTUDIANTE) {
            (cobroBase * 0.85).toInt()
        } else {
            cobroBase.toInt()
        }
    }
}